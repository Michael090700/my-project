package com.example.ezycommerce;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BookData {

    @SerializedName("id")
    @Expose
    public int id;

    @SerializedName("name")
    @Expose
    public String name;

    @SerializedName("description")
    @Expose
    public String description;

    @SerializedName("price")
    @Expose
    public float price;

    @SerializedName("author")
    @Expose
    public String author;

    @SerializedName("type")
    @Expose
    public String type;

    @SerializedName("img")
    @Expose
    public String img;

    @SerializedName("inCart")
    @Expose
    public Boolean inCart;

    @SerializedName("category")
    @Expose
    public String category;

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public float getPrice() {
        return price;
    }

    public String getAuthor() {
        return author;
    }

    public String getType() {
        return type;
    }

    public String getImg() {
        return img;
    }

    public Boolean getInCart() {
        return inCart;
    }

    public String getCategory() {
        return category;
    }
}


