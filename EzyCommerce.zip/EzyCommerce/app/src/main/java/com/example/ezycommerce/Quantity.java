package com.example.ezycommerce;

import java.util.ArrayList;
import java.util.Vector;

public class Quantity {

    private BookData bookData;
    private int quantity;

    public Quantity(BookData bookData, int quantity){

        this.bookData = bookData;
        this.quantity = quantity;
    }

    public BookData getBookData(){
        return bookData;
    }

    public int getQuantity(){
        return quantity;
    }

    public void setQuantity(int quantity){
        this.quantity = quantity;
    }

    static class Cart{
        public static Vector<Quantity> listCart = new Vector<>();
        public static float subTotal(){
            float sTotal=0;
            for (Quantity quantity:listCart){
                sTotal+=quantity.subTotal();
            }
            return sTotal;
        }
    }

    public float subTotal(){
        return bookData.getPrice()*quantity;
    }

}
