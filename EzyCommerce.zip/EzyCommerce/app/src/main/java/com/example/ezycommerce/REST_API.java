package com.example.ezycommerce;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface REST_API {

    @GET("staging/book/")
    Call<DataUser> callDataAll(@Query("nim") String nim, @Query("nama") String nama);

    @GET("staging/book/{bookId}/")
    Call<DataUser> callDataUnit(@Path("bookId") int bookId, @Query("nim") String nim, @Query("nama") String nama);
}
