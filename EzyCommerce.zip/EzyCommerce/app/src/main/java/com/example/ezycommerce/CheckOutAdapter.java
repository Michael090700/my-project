package com.example.ezycommerce;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.icu.text.Transliterator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class CheckOutAdapter extends RecyclerView.Adapter<CheckOutAdapter.CheckOutViewHolder> {

    List<Quantity> quantities;
    Context context;

    public CheckOutAdapter(List<Quantity> quantities, Context context) {
        this.quantities = quantities;
        this.context =context;
    }

    @NonNull
    @Override
    public CheckOutViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.checkout_row, viewGroup, false);
        return new CheckOutViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final CheckOutViewHolder viewHolder, int i) {
        Quantity quantity = quantities.get(i);
        Picasso.get().load(quantities.get(i).getBookData().getImg()).into(viewHolder.bookimage);
        viewHolder.booktitle.setText(quantities.get(i).getBookData().getName());
        viewHolder.bookprice.setText("$ " + quantities.get(i).getBookData().getPrice());
        viewHolder.quantity.setText(Integer.toString(quantities.get(i).getQuantity()));
        viewHolder.plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, CheckOut.class);
                quantities.get(i).setQuantity(quantity.getQuantity() + 1);
                ((Activity) context).startActivityForResult(intent, Activity.RESULT_OK);
                ((Activity) context).finish();
            }
        });
        viewHolder.minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, CheckOut.class);
                if (quantity.getQuantity() > 1){
                    quantities.get(i).setQuantity(quantity.getQuantity() - 1);
                }else{
                    Quantity.Cart.listCart.remove(i);
                }
                ((Activity) context).startActivityForResult(intent, Activity.RESULT_OK);
                ((Activity) context).finish();
            }
        });
    }

    @Override
    public int getItemCount() {
        return quantities.size();
    }

    public class CheckOutViewHolder extends RecyclerView.ViewHolder{

        TextView booktitle, bookprice, quantity;
        ImageView bookimage;
        Button minus, plus;
//      ConstraintLayout mainLayout;


        public CheckOutViewHolder(@NonNull View itemView) {
            super(itemView);
            quantity = itemView.findViewById(R.id.Quantity);
            minus = itemView.findViewById(R.id.Minus);
            plus = itemView.findViewById(R.id.Plus);
            bookimage = itemView.findViewById(R.id.gambar);
            booktitle = itemView.findViewById(R.id.nama);
            bookprice = itemView.findViewById(R.id.harga);
//          mainLayout = itemView.findViewById(R.id.mainLayout);
        }
    }
}