package com.example.ezycommerce;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.Vector;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class CheckOut extends AppCompatActivity {

    RecyclerView recyclerView;

    String UserName;

    CheckOutAdapter checkOutAdapter;

    TextView subtotal, shipping, taxes, total, name, price, loggedname;
    Button checkout, cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_out);

        subtotal = findViewById(R.id.subTotal);
        subtotal.setText("SubTotal = $" + Quantity.Cart.subTotal());
        shipping = findViewById(R.id.Shipping);
        shipping.setText("Shipping = $0 (FREE)");
        taxes = findViewById(R.id.Taxes);
        taxes.setText("Taxes = $" + Quantity.Cart.subTotal()*0.1);
        total = findViewById(R.id.Total);
        total.setText("Total = $" + Quantity.Cart.subTotal()*1.1);
        checkout = findViewById(R.id.buttonCheckOut);
        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Quantity.Cart.listCart.clear();
                Intent intent = new Intent(CheckOut.this, MainActivity.class);
                startActivityForResult(intent, Activity.RESULT_OK);
                finish();
            }
        });
        cancel = findViewById(R.id.buttonCancel);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CheckOut.this, MainActivity.class);
                startActivity(intent);
            }
        });

        loggedname = findViewById(R.id.loggedname);

        Retrofit retrofit = new Retrofit.Builder().baseUrl("https://u73olh7vwg.execute-api.ap-northeast-2.amazonaws.com/").addConverterFactory(GsonConverterFactory.create()).build();

        REST_API service = retrofit.create(REST_API.class);
        Call<DataUser> data = service.callDataAll("2201760794","Julio");
        data.enqueue(new Callback<DataUser>() {
            @Override
            public void onResponse(Call<DataUser> call, Response<DataUser> response) {
                UserName = response.body().nama;
                loggedname.setText(UserName);
            }

            @Override
            public void onFailure(Call<DataUser> call, Throwable t) {
                call.cancel();
            }
        });

        name = findViewById(R.id.nama);
        price = findViewById(R.id.harga);

        recyclerView = findViewById(R.id.recyclerViewCheckOut);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        checkOutAdapter = new CheckOutAdapter(Quantity.Cart.listCart, this);
        recyclerView.setAdapter(checkOutAdapter);
    }
}