package com.example.ezycommerce;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.Vector;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BookDetail extends AppCompatActivity {


    Integer BookId;

    String UserName;

    TextView loggedName;

    TextView title, price, description;
    ImageView image;
    Button beli;

    BookData bookData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_detail);

        BookId = getIntent().getExtras().getInt("bookId");

        title = findViewById(R.id.booktitle);
        price = findViewById(R.id.bookprice);
        description = findViewById(R.id.bookdesc);
        image = findViewById(R.id.bookimage);
        beli = findViewById(R.id.buttonBeli);
        loggedName = findViewById(R.id.loggedName);

        Retrofit retrofit = new Retrofit.Builder().baseUrl("https://u73olh7vwg.execute-api.ap-northeast-2.amazonaws.com/").addConverterFactory(GsonConverterFactory.create()).build();

        REST_API service = retrofit.create(REST_API.class);
        Call<DataUser> data = service.callDataUnit( BookId, "2201760794","Julio");
        data.enqueue(new Callback<DataUser>() {
            @Override
            public void onResponse(Call<DataUser> call, Response<DataUser> response) {
                UserName = response.body().nama;
                loggedName.setText(UserName);
                bookData = response.body().bookData.get(0);
                title.setText(bookData.getName());
                price.setText("$" + bookData.getPrice());
                description.setText(bookData.getDescription());
                Picasso.get().load(bookData.getImg()).into(image);

            }

            @Override
            public void onFailure(Call<DataUser> call, Throwable t) {
                call.cancel();
            }
        });

        beli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Quantity.Cart.listCart.add(new Quantity(bookData, 1));
                Intent intent = new Intent(BookDetail.this, CheckOut.class);
                startActivity(intent);
            }
        });
    }
}