package com.example.ezycommerce;

import android.content.Context;
import android.content.Intent;
import android.icu.text.Transliterator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.BookViewHolder> {

    List<BookData> bookdata;
    Context context;

    public MainAdapter(List<BookData> bookdata, Context context) {
        this.bookdata = bookdata;
        this.context =context;
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.main_row, viewGroup, false);
        return new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final BookViewHolder viewHolder, int i) {
        BookData bookData = bookdata.get(i);
        Picasso.get().load(bookdata.get(i).img).into(viewHolder.bookimage);
        viewHolder.booktitle.setText(bookdata.get(i).name);
        viewHolder.bookprice.setText("$ " + bookdata.get(i).price);

    }

    @Override
    public int getItemCount() {
        return bookdata.size();
    }

    public class BookViewHolder extends RecyclerView.ViewHolder{

        TextView booktitle, bookprice;
        ImageView bookimage;
//      ConstraintLayout mainLayout;


        public BookViewHolder(@NonNull View itemView) {
            super(itemView);
            bookimage = itemView.findViewById(R.id.BookImage);
            booktitle = itemView.findViewById(R.id.BookTitle);
            bookprice = itemView.findViewById(R.id.BookPrice);
//          mainLayout = itemView.findViewById(R.id.mainLayout);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(context, booktitle.getText(), Toast.LENGTH_SHORT).show();
                    int position = getAdapterPosition();
                    BookData bookData =bookdata.get(position);
                    Intent intent = new Intent(context, BookDetail.class);
                    intent.putExtra("bookId", bookdata.get(position).id);
                    context.startActivity(intent);
                }
            });
        }
    }
}

