package com.example.ezycommerce;

import java.util.Vector;

public class SavedData {
    public static Vector<BookData> bookData;

}
