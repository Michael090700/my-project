package com.example.ezycommerce;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Vector;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    String UserName;

    String Genre;

    Vector <BookData> bookData = new Vector<>();

    TextView loggedName;
    Button scifiButton, accessoriesButton, businessButton, mysteryButton, cookBookButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loggedName = findViewById(R.id.LoggedName);
        scifiButton = findViewById(R.id.ScifiButton);
        accessoriesButton = findViewById(R.id.AccessoriesButton);
        businessButton = findViewById(R.id.BusinessButton);
        mysteryButton = findViewById(R.id.MysteryButton);
        cookBookButton = findViewById(R.id.CookbookButton);

        Retrofit retrofit = new Retrofit.Builder().baseUrl("https://u73olh7vwg.execute-api.ap-northeast-2.amazonaws.com/").addConverterFactory(GsonConverterFactory.create()).build();

        REST_API service = retrofit.create(REST_API.class);
        Call<DataUser> data = service.callDataAll("2201760794","Julio");
        data.enqueue(new Callback<DataUser>() {
            @Override
            public void onResponse(Call<DataUser> call, Response<DataUser> response) {
                UserName = response.body().nama;
                loggedName.setText(UserName);
                SavedData.bookData = response.body().bookData;
                BookFragment bookFragment = new BookFragment(SavedData.bookData);
                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.fragment, bookFragment);
                fragmentTransaction.commit();
//                Toast.makeText(MainActivity.this, SavedData.bookData.get(0).getName(), Toast.LENGTH_SHORT).show();

                scifiButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        BookFragment bookFragment = new BookFragment(SavedData.bookData, "scifi");
                        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                        fragmentTransaction.replace(R.id.fragment, bookFragment);
                        fragmentTransaction.commit();
                    }
                });

                accessoriesButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        BookFragment bookFragment = new BookFragment(SavedData.bookData, "accessories");
                        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                        fragmentTransaction.replace(R.id.fragment, bookFragment);
                        fragmentTransaction.commit();
                    }
                });

                businessButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        BookFragment bookFragment = new BookFragment(SavedData.bookData, "business");
                        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                        fragmentTransaction.replace(R.id.fragment, bookFragment);
                        fragmentTransaction.commit();
                    }
                });

                mysteryButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        BookFragment bookFragment = new BookFragment(SavedData.bookData, "mystery");
                        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                        fragmentTransaction.replace(R.id.fragment, bookFragment);
                        fragmentTransaction.commit();
                    }
                });

                cookBookButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        BookFragment bookFragment = new BookFragment(SavedData.bookData, "cookbooks");
                        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                        fragmentTransaction.replace(R.id.fragment, bookFragment);
                        fragmentTransaction.commit();
                    }
                });
            }

            @Override
            public void onFailure(Call<DataUser> call, Throwable t) {
                call.cancel();
            }
        });

    }
}