package com.example.ezycommerce;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Vector;

public class DataUser {
    @SerializedName("statusCode")
    @Expose
    public int statusCode;

    @SerializedName("nim")
    @Expose
    public String nim;

    @SerializedName("nama")
    @Expose
    public String nama;

    @SerializedName("productId")
    @Expose
    public int productId;

    @SerializedName("credits")
    @Expose
    public String credits;

    @SerializedName("products")
    @Expose
    public Vector <BookData> bookData;
}
