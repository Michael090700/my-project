package com.example.ezycommerce;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class BookFragment extends Fragment {

    RecyclerView recyclerView;

    List<BookData> bookDataList;

    MainAdapter mainAdapter;

    public BookFragment(List<BookData> bookdata, String category) {
        Vector<BookData> bookGenre = new Vector<>();
        for (BookData bookData : bookdata){
            if (bookData.getCategory().equals(category)) {
                bookGenre.add(bookData);
            }
        }
        bookDataList = bookGenre;
    }

    public BookFragment(List<BookData> bookdata) {
        bookDataList = bookdata;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_book, container, false);
        recyclerView = view.findViewById(R.id.RecyclerViewBook);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        mainAdapter = new MainAdapter(bookDataList, getContext());
        recyclerView.setAdapter(mainAdapter);
        return view;
    }
}