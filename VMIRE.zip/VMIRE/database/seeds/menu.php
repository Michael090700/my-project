<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class menu extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('menu')->insert([
            ['categories_id' => '1', 'menu_name' => 'Ayam goreng', 'menu_price' => 17000],
            ['categories_id' => '2', 'menu_name' => 'Bebek goreng', 'menu_price' => 20000],
        ]);
    }
}
