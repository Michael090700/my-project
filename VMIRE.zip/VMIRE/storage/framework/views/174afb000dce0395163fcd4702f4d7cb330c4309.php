<nav class="navbar navbar-expand-lg " style="background-color: palevioletred">
    <div class="container-fluid">
        <a class="navbar-brand" href="/">VMIRE</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">

                <?php if(Auth::cashier()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo e(Auth::cashier()->username); ?>

                        </a>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/login')); ?>">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/register')); ?>">Register</a>
                        </li>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/login')); ?>">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/register')); ?>">Register</a>
                    </li>
                <?php endif; ?>

                <li class="nav-item">
                    <a class="nav-link">
                        <?php echo e(\Illuminate\Support\Carbon::now()->format('D, d M Y')); ?>

                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\VMIRE\resources\views/navbar.blade.php ENDPATH**/ ?>