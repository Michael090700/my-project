
<?php $__env->startSection('title', 'VMIRE'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-4" style="background-color: pink">
        <div class="card">
            <div class="card-header" style="background-color: pink">
                <h1 class="text-center" class="mt-3">Register</h1>
            </div>

            <div class="card-body" style="background-color: pink">
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $E): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger">
                            <?php echo e($E); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <form action="<?php echo e(url('/register')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="form-inline mt-5">
                        <div class="col">
                            <label for="username">
                                UserName:
                            </label>
                        </div>
                        <div class="col">
                            <input type="text" name="username" id="username" class="form-control">
                        </div>
                    </div>

                    <div class="form-inline mt-3">
                        <div class="col">
                            <label for="email">
                                E-mail Address:
                            </label>
                        </div>
                        <div class="col">
                            <input type="email" name="email" id="email" class="form-control">
                        </div>
                    </div>

                    <div class="form-inline mt-3">
                        <div class="col">
                            <label for="password">
                                Password:
                            </label>
                        </div>
                        <div class="col">
                            <input type="password" name="Password" id="password" class="form-control">
                        </div>
                    </div>

                    <div class="form-inline mt-3">
                        <div class="col">
                        </div>
                        <div class="col">
                            <button type="submit" class="btn btn-primary" value="login">
                                Register
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VMIRE\resources\views//register.blade.php ENDPATH**/ ?>