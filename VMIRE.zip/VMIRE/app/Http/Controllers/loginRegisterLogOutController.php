<?php

namespace App\Http\Controllers;

use App\Http\Requests\register;
use App\User;
use Illuminate\Http\Request;

class loginRegisterLogOutController extends Controller
{

    public function getRegisterPage()
    {
        return view('register');
    }

    public function register(register $reg)
    {
        $user = new User();
        $user->name = $reg['username'];
        $user->email = $reg['email'];
        $user->password = bcrypt($reg['password']);
        $user->save();
        
    }

}
