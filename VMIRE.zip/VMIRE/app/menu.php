<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class menu extends Model
{
    use SoftDeletes;
    protected $table = 'menu';
    public function category()
    {
        return $this->belongsTo('App\category');
    }

    public function transactiondetail()
    {
        return $this->hasMany('App\transactiondetail');
    }

    public function cart()
    {
        return $this->hasMany('App\cart');
    }
}
