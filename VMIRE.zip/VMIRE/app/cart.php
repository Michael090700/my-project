<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cart extends Model
{
    protected $table = 'cart';
    public function menu()
    {
        return $this->belongsTo('App\menu');
    }
    public function User()
    {
        return $this->belongsTo('App\User');
    }
}
