<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class transactiondetail extends Model
{
    protected $table = 'TransactionsDetail';
    public function menu()
    {
        return $this->belongsTo('App\menu');
    }
    public function transactionheader()
    {
        return $this->belongsTo('App\transactionheader');
    }
}
