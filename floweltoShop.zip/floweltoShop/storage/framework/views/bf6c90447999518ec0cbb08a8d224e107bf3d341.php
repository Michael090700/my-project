
<?php $__env->startSection('title', 'FloweltoShop, tempat jual kembang'); ?>
<?php $__env->startSection('content'); ?>
    <h1 class="text-center mt-5">Welcome to Flowelto Shop</h1>
    <h3 class="text-center">The Best Flower Shop in Binus University</h3>
    <div class="container mt-5">
        <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $C): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 mt-3">
                    <a href="<?php echo e(url('/flowers/' . $C->id)); ?>">
                        <div class="card">
                            <img src="<?php echo e(asset($C->categories_Image)); ?>" alt="" class="card-img-top">
                            <div class="card-body text-center">
                                <?php echo e($C->name); ?>

                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wilso\Documents\Semester 5\Web Programming\floweltoShop\resources\views/index.blade.php ENDPATH**/ ?>