<nav class="navbar navbar-expand-lg " style="background-color: palevioletred">
    <div class="container-fluid">
        <a class="navbar-brand" href="/">FloweltoShop</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Categories
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <?php if(isset($categories) && count($categories) > 0): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item" href=""><?php echo e($cate->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </li>

                <?php if(Auth::user()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <?php if(Auth::user()->role == 'Manager'): ?>
                            <a class="dropdown-item" href="<?php echo e(url('/addflower')); ?>">Add Flower</a>
                            <a class="dropdown-item" href="<?php echo e(url('/category/all')); ?>">Manage Categories</a> 
                          <?php else: ?>
                            <a class="dropdown-item" href="<?php echo e(url('/yourcart/')); ?>">My Cart</a>
                            <a class="dropdown-item" href="<?php echo e(url('/transactionhistory/')); ?>">Transaction History</a> 
                          <?php endif; ?>
                            <a class="dropdown-item" href="<?php echo e(url('/changepassword')); ?>">Change Password</a>
                            <a class="dropdown-item" href="<?php echo e(url('/logout')); ?>">Log Out</a> 
                        </div>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/login')); ?>">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/register')); ?>">Register</a>
                    </li>
                <?php endif; ?>

                <li class="nav-item">
                    <a class="nav-link">
                        <?php echo e(\Illuminate\Support\Carbon::now()->format('D, d M Y')); ?>

                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\wilso\Documents\Semester 5\Web Programming\floweltoShop\resources\views/navbar.blade.php ENDPATH**/ ?>