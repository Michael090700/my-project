
<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <h1>Your Transaction at <?php echo e($transactionheader[0]->created_at); ?></h1>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $E): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger">
                    <?php echo e($E); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <table class="table table-striped table-dark">
            <thead>
                <th scope="col"> Flower Image </th>
                <th scope="col"> Flower Name </th>
                <th scope="col"> Subtotal </th>
                <th scope="col"> Quantity </th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $transactionheader; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td>
                        <tr>
                            <th><img src="<?php echo e(asset($th->product->Flower_Image)); ?>"></th>
                            <td class="text-center"><?php echo e($th->product->Flower_Name); ?></td>
                            <td class="text-center"><?php echo e($th->product->Flower_Price * $th->quantity); ?></td>
                            <td class="text-center"><?php echo e($th->quantity); ?></td>
                        </tr>
                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="float-right">
            Total Price Rp. <?php echo e($GrandTotal); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wilso\Documents\Semester 5\Web Programming\floweltoShop\resources\views/transactionDetail.blade.php ENDPATH**/ ?>