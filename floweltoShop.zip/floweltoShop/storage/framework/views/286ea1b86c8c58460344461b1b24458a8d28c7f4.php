
<?php $__env->startSection('title', 'FloweltoShop'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-4" style="background-color: pink">
        <div class="card">
            <div class="card-header" style="background-color: pink">
                <h1 class="text-center" class="mt-3">Change Password</h1>
            </div>

            <div class="card-body" style="background-color: pink">
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $E): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger">
                            <?php echo e($E); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <form action="<?php echo e(url('/changepassword')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-inline">
                        <div class="col">
                            <label>
                                Your Password
                            </label>
                        </div>
                        <div class="col">
                            <input type="password" name="YourPassword" class="form-control">
                        </div>
                    </div>

                    <div class="form-inline">
                        <div class="col">
                            <label>
                                New Password
                            </label>
                        </div>
                        <div class="col">
                            <input type="password" name="NewPassword" class="form-control">
                        </div>
                    </div>

                    <div class="form-inline">
                        <div class="col">
                            <label>
                                Confirm New Password
                            </label>
                        </div>
                        <div class="col">
                            <input type="password" name="ConfirmPassword" class="form-control">
                        </div>
                    </div>

                    <div class="form-inline">
                        <div class="col">
                        </div>

                        <div class="col">
                            <button type="submit" class="btn btn-primary">
                                Change Password
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wilso\Documents\Semester 5\Web Programming\floweltoShop\resources\views//changePassword.blade.php ENDPATH**/ ?>