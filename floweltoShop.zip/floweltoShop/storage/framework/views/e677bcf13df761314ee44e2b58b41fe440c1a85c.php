
<?php $__env->startSection('title', e($flower->Flower_Name)); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $E): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger">
                    <?php echo e($E); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div class="row">
            <div class="col-4 mt-3">
                <img src="<?php echo e(asset($flower->Flower_Image)); ?>" width="300px" >
            </div>
            <div class="col-8">
                <form action="<?php echo e(url('/flowers/'.$flower->id.'/edit')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-inline row mb-2 mt-3">
                        <label class="col-4">Category: </label>
                        <select name="Category" id="Category">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $C): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($C->id); ?>"><?php echo e($C->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-inline row mb-2 mt-3">
                        <label class="col-4">Flower Name: </label>
                        <input type="text" name="Flower_Name" id="Flower_Name" class="form-control col-4" value="<?php echo e($flower->Flower_Name); ?>">
                    </div>

                    <div class="form-inline row mb-2 mt-3">
                        <label class="col-4">Flower Price: </label>
                        <input type="number" name="FlowerPrice" id="FlowerPrice" class="form-control col-4" value="<?php echo e($flower->Flower_Price); ?>">
                    </div>

                    <div class="form-inline row mb-2 mt-3">
                        <label class="col-4">Description: </label>
                        <textarea type="text" name="Description" id="Description" class="form-control col-4"><?php echo e($flower->Description); ?></textarea>
                    </div>

                    <div class="form-inline row mb-2 mt-3">
                        <label class="col-4">Flower Image: </label>
                        <input type="file" name="Flower_Image" id="Flower_Image" class="col-4">
                    </div>

                    <div class="row">
                        <div class="col-4">

                        </div>
                        <div class="col-4 mt-3">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wilso\Documents\Semester 5\Web Programming\floweltoShop\resources\views/flowerUpdate.blade.php ENDPATH**/ ?>