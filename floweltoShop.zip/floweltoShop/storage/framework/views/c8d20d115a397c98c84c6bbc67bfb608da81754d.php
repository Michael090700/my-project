
<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <h1>Your Cart</h1>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $E): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger">
                    <?php echo e($E); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <table class="table table-striped table-dark">
            <tbody>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $C): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <th><img src="<?php echo e(asset($C->product->Flower_Image)); ?>"></th>
                <td class="text-center"><?php echo e($C->product->Flower_Name); ?></td>
                <td class="text-center"><?php echo e($C->product->Flower_Price); ?></td>
                <td><form action="<?php echo e(url('/cart/yourcart/'. $C->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="number" name="Quantity" value="<?php echo e($C->quantity); ?>">
                    <button class="ml-5" type="submit">Update</button>
                </form></td>
              </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <a href="/checkout" class="btn btn-danger">
              Checkout
          </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wilso\Documents\Semester 5\Web Programming\floweltoShop\resources\views/YourCart.blade.php ENDPATH**/ ?>