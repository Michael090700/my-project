
<?php $__env->startSection('title', 'FloweltoShop, tempat jual kembang'); ?>
<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Manage Categories</h1>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $C): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 mt-3">
                    <div class="card">
                        <img src="<?php echo e(asset($C->categories_Image)); ?>" alt="" class="card-img-top">
                        <div class="card-body text-center">
                            <?php echo e($C->name); ?>

                            <div class="mt-2">
                                <a href="<?php echo e(url('/category/'.$C->id.'/delete')); ?>" class="btn btn-danger">Delete Category</a>
                                <a href="<?php echo e(url('/category/'.$C->id.'/edit')); ?>" class="btn btn-primary">Update Category</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wilso\Documents\Semester 5\Web Programming\floweltoShop\resources\views/category.blade.php ENDPATH**/ ?>