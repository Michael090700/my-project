
<?php $__env->startSection('title', e($category->name)); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $E): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger">
                    <?php echo e($E); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div class="row">
            <div class="col-4 mt-3">
                <img src="<?php echo e(asset($category->categories_Image)); ?>" width="300px" >
            </div>
            <div class="col-8">
                <form action="<?php echo e(url('/category/'.$category->id.'/edit')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-inline row mb-2 mt-3">
                        <label class="col-4">Category Name: </label>
                        <input type="text" name="name" id="name" class="form-control col-4" value="<?php echo e($category->name); ?>">
                    </div>
                    <div class="form-inline row mb-2 mt-3">
                        <label class="col-4">Category Image: </label>
                        <input type="file" name="categories_Image" id="categories_Image" class="col-4">
                    </div>
                    <div class="row">
                        <div class="col-4">

                        </div>
                        <div class="col-4 mt-3">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wilso\Documents\Semester 5\Web Programming\floweltoShop\resources\views/updateCategory.blade.php ENDPATH**/ ?>