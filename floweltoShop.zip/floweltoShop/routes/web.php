<?php

use App\Http\Controllers\TransactionController;
use App\Http\Requests\updateCategory;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'CategoryController@index');

Route::get('/flowers/{id}', 'ProductController@FlowerHome');

Route::get('/category/all', 'CategoryController@ManageCategory')->middleware('role:Manager');

Route::get('/logout', 'loginRegisterLogOutController@logout')->middleware('auth');

Route::get('/flower/{id}/delete', 'ProductController@DeleteFlower')->middleware('role:Manager');

Route::get('/category/{id}/delete', 'CategoryController@DeleteCategory')->middleware('role:Manager');

Route::get('/detailflower/{id}', 'ProductController@DetailFlower');

Route::post('/addflower', 'ProductController@StoreProduct')->middleware('role:Manager');
Route::get('/addflower', 'ProductController@AddProduct')->middleware('role:Manager');

Route::post('/flowers/{id}/edit', 'ProductController@UpdateFlower')->middleware('role:Manager');
Route::get('/flowers/{id}/edit', 'ProductController@Edit')->middleware('role:Manager');

Route::post('/category/{id}/edit', 'CategoryController@updateCategory')->middleware('role:Manager');
Route::get('/category/{id}/edit', 'CategoryController@Edit')->middleware('role:Manager');

Route::post('/login', 'loginRegisterLogOutController@Login')->name('login')->middleware('guest');
Route::get('/login', 'loginRegisterLogOutController@getLoginPage')->middleware('guest'); 

Route::post('/register', 'loginRegisterLogOutController@register')->name('register')->middleware('guest');; 
Route::get('/register', 'loginRegisterLogOutController@getRegisterPage')->middleware('guest');; 

Route::post('/cart/{id}', 'TransactionController@AddtoCart')->middleware('role:Customer');

Route::get('/checkout', 'TransactionController@CheckOut')->middleware('role:Customer');

Route::post('/cart/yourcart/{id}', 'TransactionController@YourCart')->middleware('role:Customer');
Route::get('/yourcart', 'TransactionController@ViewCart')->middleware('role:Customer'); 

Route::get('/transactionhistory', 'TransactionController@TransactionHeader')->middleware('role:Customer');

Route::get('/transactiondetail/{id}', 'TransactionController@TransactionDetail')->middleware('role:Customer');

Route::post('/changepassword', 'loginRegisterLogOutController@ChangePassword')->middleware('auth');
Route::get('/changepassword', 'loginRegisterLogOutController@ConfirmChangePassword')->middleware('auth');

Route::get('/home', function(){
    return redirect('/');
});















