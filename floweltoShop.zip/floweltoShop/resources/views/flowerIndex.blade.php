@extends('template')
@section('title', 'FloweltoShop, tempat jual kembang')
@section('content')
    <h1 class="text-center mt-5">{{$category->name}}</h1>
    <div class="container mt-5">
        <div class="row">
            @foreach ($products as $P)
                <div class="col-3 mt-3">
                    <a href="{{ url('/detailflower/'.$P->id)}}">
                        <div class="card">
                            <img src="{{ asset($P->Flower_Image) }}" alt="" class="card-img-top">
                            <div class="card-body text-center">
                                {{ $P->Flower_Name }}
                            </div>
                            <div class="card-body text-center">
                                {{ $P->Flower_Price }}
                                @if (Auth::user() && Auth::user()->role == 'Manager')
                                    <div class="mt-2">
                                        <a href="{{ url('/flower/' . $P->id . '/delete') }}" class="btn btn-danger">Delete
                                            Flower</a>
                                        <a href="{{ url('/flowers/' . $P->id . '/edit') }}" class="btn btn-primary">Update
                                            Flower</a>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </a>
                </div>
            @endforeach
        </div>
    </div>
@endsection
