@extends('template')
@section('title', e($category->name))
@section('content')
    <div class="container mt-3">
        @if ($errors->any())
            @foreach ($errors->all() as $E)
                <div class="alert alert-danger">
                    {{ $E }}
                </div>
            @endforeach
        @endif
        <div class="row">
            <div class="col-4 mt-3">
                <img src="{{ asset($category->categories_Image) }}" width="300px" >
            </div>
            <div class="col-8">
                <form action="{{ url('/category/'.$category->id.'/edit') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="form-inline row mb-2 mt-3">
                        <label class="col-4">Category Name: </label>
                        <input type="text" name="name" id="name" class="form-control col-4" value="{{ $category->name }}">
                    </div>
                    <div class="form-inline row mb-2 mt-3">
                        <label class="col-4">Category Image: </label>
                        <input type="file" name="categories_Image" id="categories_Image" class="col-4">
                    </div>
                    <div class="row">
                        <div class="col-4">

                        </div>
                        <div class="col-4 mt-3">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
