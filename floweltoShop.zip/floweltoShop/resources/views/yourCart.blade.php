@extends('template')
@section('content')
    <div class="container mt-3">
        <h1>Your Cart</h1>
        @if ($errors->any())
            @foreach ($errors->all() as $E)
                <div class="alert alert-danger">
                    {{ $E }}
                </div>
            @endforeach
        @endif
        <table class="table table-striped table-dark">
            <tbody>
                @foreach ($cart as $C)
                <tr>
                <th><img src="{{asset($C->product->Flower_Image)}}"></th>
                <td class="text-center">{{$C->product->Flower_Name}}</td>
                <td class="text-center">{{$C->product->Flower_Price}}</td>
                <td><form action="{{ url('/cart/yourcart/'. $C->id)}}" method="POST">
                    @csrf
                    <input type="number" name="Quantity" value="{{$C->quantity}}">
                    <button class="ml-5" type="submit">Update</button>
                </form></td>
              </tr>
                @endforeach
            </tbody>
          </table>
          <a href="/checkout" class="btn btn-danger">
              Checkout
          </a>
    </div>
@endsection
