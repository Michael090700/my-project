@extends('template')
@section('content')
    <div class="container mt-3">
        <h1>Your Transaction at {{ $transactionheader[0]->created_at }}</h1>
        @if ($errors->any())
            @foreach ($errors->all() as $E)
                <div class="alert alert-danger">
                    {{ $E }}
                </div>
            @endforeach
        @endif
        <table class="table table-striped table-dark">
            <thead>
                <th scope="col"> Flower Image </th>
                <th scope="col"> Flower Name </th>
                <th scope="col"> Subtotal </th>
                <th scope="col"> Quantity </th>
            </thead>
            <tbody>
                @foreach ($transactionheader as $th)
                    <td>
                        <tr>
                            <th><img src="{{ asset($th->product->Flower_Image) }}"></th>
                            <td class="text-center">{{ $th->product->Flower_Name }}</td>
                            <td class="text-center">{{ $th->product->Flower_Price * $th->quantity}}</td>
                            <td class="text-center">{{ $th->quantity }}</td>
                        </tr>
                    </td>
                @endforeach
            </tbody>
        </table>
        <div class="float-right">
            Total Price Rp. {{$GrandTotal}}
        </div>
    </div>
@endsection
