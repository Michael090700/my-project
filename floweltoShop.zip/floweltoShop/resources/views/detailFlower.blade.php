@extends('template')
@section('content')
    <div class="container">
        <img class="col-6 mt-3" style="width: 30%; height: 400px; " src="{{ asset($flower->Flower_Image) }}">
        <div class="col-6 mt-3">
            {{ $flower->Flower_Name }}
        </div>
        <div>
            {{ 'Rp' . $flower->Flower_Price }}
        </div>
        <div>
            {{ $flower->Description }}
        </div>
        <div>
            @if ($errors->any())
                @foreach ($errors->all() as $E)
                    <div class="alert alert-danger">
                        {{ $E }}
                    </div>
                @endforeach
            @endif
            @if (Auth::user())
                @if (Auth::user()->role == 'Customer')
                    <form action="{{ url('/cart/'. $flower->id) }}" method="POST">
                        @csrf
                        <label>Quantity</label>
                        <input type="number" name="Quantity" min="1" id="Quantity">
                        <button type="submit" class="btn btn-primary">Add to cart</button>
                    </form>
                @endif
            @else
                <form action="{{ url('/login') }}" method="GET">
                    <label>Quantity</label>
                    <input type="number" name="Quantity" min="1" id="Quantity">
                    <button type="submit" class="btn btn-primary">Add to cart</button>
                </form>
            @endif
        </div>
    </div>
@endsection
