@extends('template')
@section('title', e($flower->Flower_Name))
@section('content')
    <div class="container mt-3">
        @if ($errors->any())
            @foreach ($errors->all() as $E)
                <div class="alert alert-danger">
                    {{ $E }}
                </div>
            @endforeach
        @endif
        <div class="row">
            <div class="col-4 mt-3">
                <img src="{{ asset($flower->Flower_Image) }}" width="300px" >
            </div>
            <div class="col-8">
                <form action="{{ url('/flowers/'.$flower->id.'/edit') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="form-inline row mb-2 mt-3">
                        <label class="col-4">Category: </label>
                        <select name="Category" id="Category">
                            @foreach ($categories as $C)
                                <option value="{{$C->id}}">{{$C->name}}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-inline row mb-2 mt-3">
                        <label class="col-4">Flower Name: </label>
                        <input type="text" name="Flower_Name" id="Flower_Name" class="form-control col-4" value="{{ $flower->Flower_Name }}">
                    </div>

                    <div class="form-inline row mb-2 mt-3">
                        <label class="col-4">Flower Price: </label>
                        <input type="number" name="FlowerPrice" id="FlowerPrice" class="form-control col-4" value="{{ $flower->Flower_Price }}">
                    </div>

                    <div class="form-inline row mb-2 mt-3">
                        <label class="col-4">Description: </label>
                        <textarea type="text" name="Description" id="Description" class="form-control col-4">{{ $flower->Description }}</textarea>
                    </div>

                    <div class="form-inline row mb-2 mt-3">
                        <label class="col-4">Flower Image: </label>
                        <input type="file" name="Flower_Image" id="Flower_Image" class="col-4">
                    </div>

                    <div class="row">
                        <div class="col-4">

                        </div>
                        <div class="col-4 mt-3">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection