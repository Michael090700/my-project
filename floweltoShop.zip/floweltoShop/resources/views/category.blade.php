@extends('template')
@section('title', 'FloweltoShop, tempat jual kembang')
@section('content')
    <h1 class="text-center">Manage Categories</h1>
    <div class="container">
        <div class="row">
            @foreach ($categories as $C)
                <div class="col-6 mt-3">
                    <div class="card">
                        <img src="{{ asset($C->categories_Image) }}" alt="" class="card-img-top">
                        <div class="card-body text-center">
                            {{ $C->name }}
                            <div class="mt-2">
                                <a href="{{ url('/category/'.$C->id.'/delete')}}" class="btn btn-danger">Delete Category</a>
                                <a href="{{ url('/category/'.$C->id.'/edit') }}" class="btn btn-primary">Update Category</a>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection