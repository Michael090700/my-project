@extends('template')
@section('title', 'FloweltoShop')
@section('content')
    <div class="container mt-4" style="background-color: pink">
        <div class="card">
            <div class="card-header" style="background-color: pink">
                <h1 class="text-center" class="mt-3">Register</h1>
            </div>

            <div class="card-body" style="background-color: pink">
                @if ($errors->any())
                    @foreach ($errors->all() as $E)
                        <div class="alert alert-danger">
                            {{ $E }}
                        </div>
                    @endforeach
                @endif

                <form action="{{ url('/register') }}" method="POST">
                    @csrf

                    <div class="form-inline mt-5">
                        <div class="col">
                            <label for="UserName">
                                UserName:
                            </label>
                        </div>
                        <div class="col">
                            <input type="text" name="UserName" id="UserName" class="form-control">
                        </div>
                    </div>

                    <div class="form-inline mt-3">
                        <div class="col">
                            <label for="email">
                                E-mail Address:
                            </label>
                        </div>
                        <div class="col">
                            <input type="email" name="email" id="email" class="form-control">
                        </div>
                    </div>

                    <div class="form-inline mt-3">
                        <div class="col">
                            <label for="password">
                                Password:
                            </label>
                        </div>
                        <div class="col">
                            <input type="password" name="Password" id="password" class="form-control">
                        </div>
                    </div>

                    <div class="form-inline mt-3">
                        <div class="col">
                            <label for="ConfirmPassword">
                                Confirm Password:
                            </label>
                        </div>
                        <div class="col">
                            <input type="password" name="ConfirmPassword" id="ConfirmPassword" class="form-control">
                        </div>
                    </div>

                    <div class="form-inline mt-3">
                        <div class="col">
                            <label for="Gender">
                                Gender:
                            </label>
                        </div>
                        <div class="col">
                            <fieldset id="Gender" name="Gender" class="form-inline">
                                <input type="radio" name="Gender" id="male" value="Male" class="ml-4">
                                <label for="male" class="ml-1">Male</label>
                                <input type="radio" name="Gender" id="female" value="Female" class="ml-4">
                                <label for="female" class="ml-1">Female</label>
                            </fieldset>
                        </div>
                    </div>

                    <div class="form-inline mt-3">
                        <div class="col">
                            <label for="DateofBirth">
                                Date of Birth:
                            </label>
                        </div>
                        <div class="col">
                            <input type="date" placeholder="mm/dd/yyyy" name="DateofBirth" id="DateofBirth"
                                class="form-control">
                        </div>
                    </div>

                    <div class="form-inline mt-3">
                        <div class="col">
                            <label for="Address">
                                Address:
                            </label>
                        </div>
                        <div class="col">
                            <textarea type="text" placeholder="Address" name="Address" id="Address"
                                class="form-control"></textarea>
                        </div>
                    </div>

                    <div class="form-inline mt-3">
                        <div class="col">
                        </div>
                        <div class="col">
                            <button type="submit" class="btn btn-primary" value="login">
                                Register
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
