@extends('template')
@section('content')
    <div class="container mt-3">
        <h1>Your Transaction History</h1>
        @if ($errors->any())
            @foreach ($errors->all() as $E)
                <div class="alert alert-danger">
                    {{ $E }}
                </div>
            @endforeach
        @endif
        <table class="table table-striped table-dark">
            <tbody>
                @foreach ($header as $H)
                    <tr>
                        <td>
                            <a href="{{ url('/transactiondetail/' . $H->id) }}">
                                {{ $H->created_at }}
                            </a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
