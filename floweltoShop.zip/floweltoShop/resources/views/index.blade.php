@extends('template')
@section('title', 'FloweltoShop, tempat jual kembang')
@section('content')
    <h1 class="text-center mt-5">Welcome to Flowelto Shop</h1>
    <h3 class="text-center">The Best Flower Shop in Binus University</h3>
    <div class="container mt-5">
        <div class="row">
            @foreach ($categories as $C)
                <div class="col-6 mt-3">
                    <a href="{{ url('/flowers/' . $C->id) }}">
                        <div class="card">
                            <img src="{{ asset($C->categories_Image) }}" alt="" class="card-img-top">
                            <div class="card-body text-center">
                                {{ $C->name }}
                            </div>
                        </div>
                    </a>
                </div>
            @endforeach
        </div>
    </div>
@endsection
