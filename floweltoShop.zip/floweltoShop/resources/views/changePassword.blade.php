@extends('template')
@section('title', 'FloweltoShop')
@section('content')
    <div class="container mt-4" style="background-color: pink">
        <div class="card">
            <div class="card-header" style="background-color: pink">
                <h1 class="text-center" class="mt-3">Change Password</h1>
            </div>

            <div class="card-body" style="background-color: pink">
                @if ($errors->any())
                    @foreach ($errors->all() as $E)
                        <div class="alert alert-danger">
                            {{ $E }}
                        </div>
                    @endforeach
                @endif

                <form action="{{ url('/changepassword') }}" method="POST">
                    @csrf
                    <div class="form-inline">
                        <div class="col">
                            <label>
                                Your Password
                            </label>
                        </div>
                        <div class="col">
                            <input type="password" name="YourPassword" class="form-control">
                        </div>
                    </div>

                    <div class="form-inline">
                        <div class="col">
                            <label>
                                New Password
                            </label>
                        </div>
                        <div class="col">
                            <input type="password" name="NewPassword" class="form-control">
                        </div>
                    </div>

                    <div class="form-inline">
                        <div class="col">
                            <label>
                                Confirm New Password
                            </label>
                        </div>
                        <div class="col">
                            <input type="password" name="ConfirmPassword" class="form-control">
                        </div>
                    </div>

                    <div class="form-inline">
                        <div class="col">
                        </div>

                        <div class="col">
                            <button type="submit" class="btn btn-primary">
                                Change Password
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
