@extends('template')
@section('title','FloweltoShop')
@section('content')
    <div class="container mt-4" style="background-color: pink">
        <div class="card">
            <div class="card-header" style="background-color: pink">
                <h1 class="text-center" class="mt-3">Login</h1>
            </div>

            <div class="card-body" style="background-color: pink">
                @if ($errors->any())
                    @foreach ($errors->all() as $E)
                        <div class="alert alert-danger">
                            {{$E}}
                        </div>
                    @endforeach
                @endif

                <form action="{{ url('/login') }}" method="POST">
                    @csrf

                    <div class="form-inline">
                        <div class="col">
                            <label for="email">
                                E-mail Address:
                            </label>
                        </div>
                        <div class="col">
                            <input type="email" name="email" id="email" class="form-control">
                        </div>

                    </div>
                    <div class="form-inline">
                        <div class="col">
                            <label for="password">
                                Password:
                            </label>
                        </div>
                        <div class="col">
                            <input type="password" name="password" id="password" class="form-control">
                        </div>

                    </div>
                    <div class="form-inline">
                        <div class="col">

                        </div>
                        <div class="col">
                            <input type="checkbox" name="rememberMe" id="rememberMe">
                            Remember Me
                        </div>

                    </div>
                    <div class="form-inline">
                        <div class="col">

                        </div>
                        <div class="col">
                            <button type="submit" class="btn btn-primary" value="login">
                                Login
                            </button>
                            <a href="">
                                Forgot Your Password?
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
