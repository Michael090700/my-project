<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class transactiondetail extends Model
{
    protected $table = 'TransactionsDetail';
    public function product()
    {
        return $this->belongsTo('App\product');
    }
    public function transactionheader()
    {
        return $this->belongsTo('App\transactionheader');
    }
}
