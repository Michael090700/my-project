<?php

namespace App\Http\Controllers;

use App\Http\Requests\changePassword;
use Illuminate\Support\Str;
use App\Http\Requests\register;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class loginRegisterLogOutController extends Controller
{    
    public function getLoginPage()
    {
        return view('login');
    }
    
    public function login(Request $request)
    {
        $remember = $request->has('rememberMe') == null ? false : true;
        $request = $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);
        
        $login = Auth::attempt([
           'email' => $request['email'],
           'password' => $request['password']
        ],$remember); 

        if($login == true) return redirect('/');
        
        return redirect('/login')->withErrors("the email or password that you've entered is incorrect");
    }

    public function getRegisterPage()
    {
        return view('register');
    }

    public function register(register $reg)
    {
        $user = new User();
        $user->name = $reg['UserName'];
        $user->email = $reg['email'];
        $user->password = bcrypt($reg['Password']);
        $user->gender = $reg['Gender'];
        $user->date_of_birth = $reg['DateofBirth'];
        $user->address = $reg['Address'];
        $user->remember_token = Str::random(64);
        $user->save();

        return redirect('/login');
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/login');
    }

    public function ChangePassword(changePassword $request)
    {
        if(!Hash::check($request['YourPassword'], Auth::user()->password)){
            return redirect('/changePassword')->withErrors('Wrong Password!!!');
        } else {
            $user = User::where('id', '=', Auth::user()->id)->first();
            $user->password = bcrypt($request['NewPassword']);
            $user->save();
        }
        return redirect('/');
    }

    public function ConfirmChangePassword()
    {
        return view ('/changePassword');
    }

}
