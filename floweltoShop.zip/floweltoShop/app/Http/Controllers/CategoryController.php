<?php

namespace App\Http\Controllers;

use App\category;
use App\Http\Requests\updateCategory;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        $categories=category::all();
        return view('index', ['categories'=>$categories]);
    }

    public function ManageCategory()
    {
        $categories=category::all();
        return view('category', ['categories'=>$categories]);
    }

    public function DeleteCategory($id)
    {
        category::find($id)->delete();
        return redirect('/category/all');
    }

    public function UpdateCategory(updateCategory $request, $id)
    {
        $categories = category::find($id);
        $image = $request['categories_Image'];

        $fileName = 'category/'.$image->getClientOriginalName();
        $image->move('category', $image->getClientOriginalName());

        $categories->name = $request['name'];
        $categories->categories_Image = $fileName;
        $categories->save();

        return redirect('/category/all');
    }

    public function Edit($id)
    {
        $categories = category::find($id);
        return view('updateCategory', ['category' => $categories]);
    }
}
