<?php

namespace App\Http\Controllers;

use App\cart;
use App\category;
use App\transactiondetail;
use App\transactionheader;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TransactionController extends Controller
{
    public function AddtoCart(Request $request, $id)
    {
        $request = $request->validate([
            'Quantity' => 'numeric|min:1'
        ]);

        $cart = new cart();

        if(cart::where('user_id', '=', Auth::user()->id)->where('product_id', '=', $id)->first() == null){
            $cart->user_id = Auth::user()->id;
            $cart->product_id = $id;
            $cart->quantity = $request['Quantity'];
        }else{
            $cart = cart::where('user_id', '=', Auth::user()->id)->where('product_id', '=', $id)->first();
            $cart->quantity = $cart->quantity + $request['Quantity'];
        }

        $cart->save();
        
        return redirect('/yourcart');
    }

    public function YourCart(Request $request, $id)
    {
        $request = $request->validate([
            'Quantity' => 'numeric|min:0'
        ]);
        if($request['Quantity']== 0){
            cart::find($id)->delete();
            return redirect('/yourcart');
        }

        $cart = cart::find($id);
        $cart->quantity = $request['Quantity'];

        $cart->save();
        
        return redirect('/yourcart');
    }

    public function ViewCart()
    {
        $cart = cart::where('user_id', '=', Auth::user()->id)->get();
        $categories = category::all();
        return view('YourCart', ['cart' => $cart, 'categories' => $categories]);
    }

    public function CheckOut()
    {
        $header = new transactionheader();
        $header->user_id = Auth::user()->id;
        $header->save();
        $header->fresh();
        $cart = cart::where('user_id', '=', Auth::user()->id)->get();
        foreach($cart as $C) {
            $detail = new transactiondetail();
            $detail->transactionsHeader_id = $header->id;
            $detail->product_id = $C->product->id;
            $detail->quantity = $C->quantity;
            $detail->save();
            $C->delete();
        }
        return redirect('/');
    }

    public function TransactionDetail($id)
    {
        $totalprice=0;
        $history = transactiondetail::where('transactionsHeader_id', '=', $id)->get();
        foreach ($history as $H) {
            $totalprice += ($H->quantity * $H->product->Flower_Price);
        }
        return view('transactionDetail', ['transactionheader'=>$history , 'GrandTotal'=>$totalprice]);
    }

    public function TransactionHeader()
    {
        $history = transactionheader::where('user_id', '=', Auth::user()->id)->get();
        return view('transactionHistory', ['header'=>$history]);

    }
}


