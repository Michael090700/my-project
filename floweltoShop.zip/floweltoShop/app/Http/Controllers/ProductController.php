<?php

namespace App\Http\Controllers;

use App\category;
use App\Http\Requests\addFlower;
use App\Http\Requests\updateCategory;
use App\Http\Requests\updateFlower;
use App\product;
use flower;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function FlowerHome($id)
    {
        $category = category::where('id', '=', $id)->first();
        $flowers=product::where('categories_id', '=', $id)->get();
        return view('flowerIndex', ['products'=>$flowers, 'category' => $category]);
    }

    public function DeleteFlower($id)
    {
        product::find($id)->delete();
        return redirect('/');
    }

    public function AddProduct()
    {
        $categories = category::all();
        return view('addflower', ['categories' => $categories]);
    }

    public function StoreProduct(addFlower $request)
    {
        $flowers = new product;
        $flowers->categories_id = $request['Category'];
        $flowers->Flower_Name = $request['Flower_Name'];
        $flowers->Flower_Price = $request['FlowerPrice'];
        $flowers->Description = $request['Description'];

        $imageFlowers = $request['FlowerImage'];
        $fileName = 'flower/'.$imageFlowers->getClientOriginalName();
        $imageFlowers->move('flower', $imageFlowers->getClientOriginalName());
        
        $flowers->Flower_Image = $fileName;
        $flowers->save();

        return redirect('/flowers/'.$request['Category']);
    }

    public function DetailFlower($id)
    {
        $flowers = product::find($id);
        return view('detailFlower', ['flower' => $flowers]);
    }

    public function UpdateFlower(Request $request, $id)
    {
        $hasImage = $request->has('Flower_Image');
        $validatedRequest = $request->validate([
            'Category' => 'required',
            'Flower_Name' => 'required|unique:products|min:5',
            'FlowerPrice' => 'required|numeric|min:50000',
            'Description' => 'required|min:20'
        ]);

        $flowers = product::find($id);
        
        $flowers->categories_id = $validatedRequest['Category'];
        $flowers->Flower_Name = $validatedRequest['Flower_Name'];
        $flowers->Flower_Price = $validatedRequest['FlowerPrice'];
        $flowers->Description = $validatedRequest['Description'];

        if($hasImage)
        {
            $imageFlowers = $request->Flower_Image;
            $fileName = 'flower/'.$imageFlowers->getClientOriginalName();
            $imageFlowers->move('flower', $imageFlowers->getClientOriginalName());

            $imageFlowers->name = $validatedRequest['Flower_Name'];
            $flowers->Flower_Image = $fileName;
        }

        $flowers->save();
        return redirect('/flowers/'.$request['Category']);
    }

    public function Edit($id)
    {
        $flowers = product::find($id);
        $categories = category::all();
        return view('flowerUpdate', ['flower' => $flowers, 'categories' => $categories]);
    }

}
