<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Database\Capsule\Manager;
use Illuminate\Support\Facades\Auth;

class check
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $role)
    {
        if($role == 'Manager'){
            if(Auth::user()->role=='Manager'){
                return $next($request);
            }else{
                abort(403, 'Forbidden - Know Your Place');
            }
        }
        else if($role == 'Customer'){
                if(Auth::user()->role =='Customer'){
                    return $next($request);
                }else{
                   abort(403, 'Forbidden - Know Your Place');
            }   
        }
    }
}
