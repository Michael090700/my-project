<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class transactionheader extends Model
{
    protected $table = 'TransactionsHeader';
    public function transactiondetail()
    {
        return $this->hasMany('App\transactiondetail');
    }
    public function User()
    {
        return $this->belongsTo('App\User');
    }
}
