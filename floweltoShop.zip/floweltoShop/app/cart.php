<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class cart extends Model
{
    protected $table = 'carts';
    public function product()
    {
        return $this->belongsTo('App\product');
    }
    public function User()
    {
        return $this->belongsTo('App\User');
    }
}
