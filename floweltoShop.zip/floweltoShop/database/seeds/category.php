<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class category extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('categories')->insert([
            ['name' => 'Hand Bouquet(gift)', 'categories_Image' => 'category/HandBouquet.jpg'],
            ['name' => 'Weeding Bouquet', 'categories_Image' => 'category/WeedingBouquet.jpg'],
            ['name' => 'Table Arrangement', 'categories_Image' => 'category/TableArrangement.jpg'],
            ['name' => 'House Arrangement', 'categories_Image' => 'category/HouseArrangement.jpg']
        ]);
    }
}
