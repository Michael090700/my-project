<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class flower extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('products')->insert([

            ['categories_id' => '1', 'Flower_Name' => 'Round Bouquet Mawar', 'Flower_Price' => 120000, 'Description' => 'Berbentuk bulat, terlihat sederhana namun tetap elegan. Cocok dikombinasikan dengan semua konsep pernikahan dan model kebaya atau dress. Memberi kesan formal dan cocok untuk pesta indoor.', 'Flower_Image' => 'flower/RoundBouquetMawar.jpg'],
            ['categories_id' => '1', 'Flower_Name' => 'Round Bouquet Baby Breath', 'Flower_Price' => 120000, 'Description' => 'Berbentuk bulat, terlihat sederhana namun tetap elegan. Cocok dikombinasikan dengan semua konsep pernikahan dan model kebaya atau dress. Memberi kesan kasual dan cocok untuk pesta outdoor.', 'Flower_Image' => 'flower/RoundBouquetBabyBreath.jpg'],
            ['categories_id' => '1', 'Flower_Name' => 'Pageant Bouquet Mawar', 'Flower_Price' => 120000, 'Description' => 'Dapat disebut dengan bunga lengan karena dibawa seperti menggendong bayi. Bentuknya uang menakjubkan menjadi simbol kehormatan wanita. Cocok digunakan untuk pesta pernikahan bergaya modern.', 'Flower_Image' => 'flower/PageantBouquetMawar.jpg'],
            ['categories_id' => '1', 'Flower_Name' => 'Cascade Bouquet', 'Flower_Price' => 120000, 'Description' => 'Berbentuk bulat diatas dan runcing di bagian bawah. Bersifat formal dan tradisional. Semua jenis bunga cocok dibentuk seperti ini.', 'Flower_Image' => 'flower/CascadeBouquet.jpg'],
            ['categories_id' => '1', 'Flower_Name' => 'Nosegay Bouquet', 'Flower_Price' => 120000, 'Description' => 'Lebih terlihat berwarna hijau menggunakan banyak daun. Cocok untuk acara private dan intimate. Digunakan juga untuk rapat dengan menyertakan pita dan kain di tangkai bunganya.', 'Flower_Image' => 'flower/NosegayBouquet.jpg'],
            ['categories_id' => '1', 'Flower_Name' => 'Pomander Bouquet', 'Flower_Price' => 120000, 'Description' => 'Berbentuk bulat seperti bola dan memiliki tali gantungan sebagai pegangannya. Terkesan mewah dan mahal. Tiap bunga memiliki ukuran yang sama. Cocok dibawa oleh gadis-gadis pembawa bunga di pernikahan.', 'Flower_Image' => 'flower/PomanderBouquet.jpg'],
            ['categories_id' => '1', 'Flower_Name' => 'Posy Bouquet Gerbera', 'Flower_Price' => 120000, 'Description' => 'Rangkaian berbentuk bulat dan tangkainya panjang . Berukuran kecil sehingga bisa dibawa dengan satu tangan. Bisa dipegang oleh bridesmaid.', 'Flower_Image' => 'flower/PosyBouquetGerbera.jpg'],
            ['categories_id' => '1', 'Flower_Name' => 'Posy Bouquet Tulip', 'Flower_Price' => 120000, 'Description' => 'Rangkaian berbentuk bulat dan tangkainya panjang . Berukuran kecil sehingga bisa dibawa dengan satu tangan. Bisa dipegang oleh bridesmaid.', 'Flower_Image' => 'flower/PosyBouquetTulip.jpg'],
            ['categories_id' => '2', 'Flower_Name' => 'Posy Bouquet Tulip', 'Flower_Price' => 120000, 'Description' => 'Rangkaian berbentuk bulat dan tangkainya panjang . Berukuran kecil sehingga bisa dibawa dengan satu tangan. Bisa dipegang oleh bridesmaid.', 'Flower_Image' => 'flower/PosyBouquetTulip.jpg'],
            ['categories_id' => '3', 'Flower_Name' => 'Posy Bouquet Tulip', 'Flower_Price' => 120000, 'Description' => 'Rangkaian berbentuk bulat dan tangkainya panjang . Berukuran kecil sehingga bisa dibawa dengan satu tangan. Bisa dipegang oleh bridesmaid.', 'Flower_Image' => 'flower/PosyBouquetTulip.jpg']
           
        ]);
    }
}
