package com.example.ezyfood;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DrinkAdapter extends RecyclerView.Adapter<DrinkAdapter.DrinkViewHolder> {

    ArrayList<minuman> listminuman;
    Context context;

    public DrinkAdapter(ArrayList<minuman> listminuman, Context context) {
        this.listminuman = listminuman;
        this.context =context;
    }

    @NonNull
    @Override
    public DrinkViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.drink_row, viewGroup, false);
        return new DrinkViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final DrinkViewHolder viewHolder, int i) {
        minuman minuman = listminuman.get(i);
        viewHolder.myImage.setImageResource(minuman.getImages());
        viewHolder.myText1.setText(minuman.getName());
        viewHolder.myText2.setText("Rp. " + minuman.getPrice());

    }

    @Override
    public int getItemCount() {
        return listminuman.size();
    }

    public class DrinkViewHolder extends RecyclerView.ViewHolder{

        TextView myText1, myText2;
        ImageView myImage;
        ConstraintLayout mainLayout;


        public DrinkViewHolder(@NonNull View itemView) {
            super(itemView);
            myImage = itemView.findViewById(R.id.drinkImageView);
            myText1 = itemView.findViewById(R.id.drinkView1);
            myText2 = itemView.findViewById(R.id.drinkView2);
            mainLayout = itemView.findViewById(R.id.mainLayout);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    minuman minuman =listminuman.get(position);
                    Intent intent = new Intent(context, Order_Activity.class);
                    intent.putExtra("drink", minuman);
                    context.startActivity(intent);
                }
            });
        }
    }
}
