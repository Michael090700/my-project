package com.example.ezyfood;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    ArrayList<OrderList> order;
    Context context;

    public OrderAdapter(ArrayList<OrderList> Lorder, Context context) {
        this.order = Lorder;
        this.context = context;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.order_row, viewGroup, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder viewHolder, int i) {
        viewHolder.image1.setImageResource(order.get(i).getDrink().getImages());
        viewHolder.text1.setText(order.get(i).getDrink().getName());
        viewHolder.text2.setText(order.get(i).getQuantity() + "x Rp. " + order.get(i).getDrink().getPrice());

        viewHolder.hilang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Data.orderlist.remove(i);
                order.remove(i);
                notifyDataSetChanged();

                Intent intent = new Intent(context, MyOrder.class);

                ((Activity) context).startActivityForResult(intent, Activity.RESULT_OK);
                ((Activity) context).finish();
            }
        });
    }

    @Override
    public int getItemCount() {
        return order.size();
    }

    public class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView text1, text2, qty;
        ImageView image1;
        Button hilang;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            image1 = itemView.findViewById(R.id.orderImageView);
            text1 = itemView.findViewById(R.id.nama);
            text2 = itemView.findViewById(R.id.harga);
            hilang = itemView.findViewById(R.id.Hapus);
            qty = itemView.findViewById(R.id.BeliBerapa);
        }
    }
}
