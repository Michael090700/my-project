package com.example.ezyfood;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class Drink_Activity extends AppCompatActivity {

    RecyclerView RecycleViewDrink;
    DrinkAdapter drinkAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink_);

        minuman minuman1 = new minuman(R.drawable.air_mineral, "Air Mineral", 3000);
        minuman minuman2 = new minuman(R.drawable.jus_apel, "Jus Apel", 10000);
        minuman minuman3 = new minuman(R.drawable.jus_mangga, "Jus Mangga", 10000);
        minuman minuman4 = new minuman(R.drawable.jus_alpukat, "Jus Alpukat", 15000);

        ArrayList<minuman> listminuman =new ArrayList<>();
        listminuman.add(minuman1);
        listminuman.add(minuman2);
        listminuman.add(minuman3);
        listminuman.add(minuman4);

        RecycleViewDrink = findViewById(R.id.RecycleViewDrink);
        drinkAdapter=new DrinkAdapter(listminuman, this);
        RecycleViewDrink.setAdapter(drinkAdapter);
        RecycleViewDrink.setLayoutManager(new LinearLayoutManager(this));

        Button MyOrder = findViewById(R.id.MyOrder);
        MyOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Drink_Activity.this, MyOrder.class);
                startActivity(intent);
            }
        });
    }
}