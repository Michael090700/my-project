package com.example.ezyfood;

import java.io.Serializable;

public class minuman implements Serializable {
    private int images;
    private String name;
    private int price;

    public minuman(int images, String name, int price){
        this.images = images;
        this.name = name;
        this.price = price;
    }

    public int getImages(){
        return this.images;
    }

    public String getName(){
        return this.name;
    }

    public int getPrice(){
        return this.price;
    }
}