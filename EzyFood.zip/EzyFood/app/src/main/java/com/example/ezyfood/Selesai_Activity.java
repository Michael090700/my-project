package com.example.ezyfood;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class Selesai_Activity extends AppCompatActivity {

    int Total= 0;

    RecyclerView RVSelesai;

    ArrayList<OrderList> orderlist;

    SelesaiAdapter sAdapter;

    Button menuutama;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selesai_);

        orderlist = new ArrayList<>(Data.orderlist);

        for (OrderList listorder: Data.orderlist) {
            Total += listorder.getQuantity() * listorder.getDrink().getPrice();

        }

        sAdapter = new SelesaiAdapter(orderlist, this);

        RVSelesai = findViewById(R.id.RVSelesai);

        RVSelesai.setAdapter(sAdapter);

        RVSelesai.setLayoutManager(new LinearLayoutManager(this));


        TextView harga = findViewById(R.id.SelesaiTextView);
        harga.setText("Total: Rp. " + Total);

        Button menuutama = findViewById(R.id.MenuUtama);
        menuutama.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                orderlist.clear();

                Data.orderlist.clear();

                Intent intent = new Intent(Selesai_Activity.this, MainActivity.class);

                startActivity(intent);
            }

        });
    }
}