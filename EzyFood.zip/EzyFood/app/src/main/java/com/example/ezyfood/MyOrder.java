package com.example.ezyfood;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class MyOrder extends AppCompatActivity {

    int Total= 0;

    RecyclerView recyclervieworder;

    ArrayList<OrderList> orderlist;

    OrderAdapter orderAdapter;

    Button paynow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_order);

        orderlist = new ArrayList<>(Data.orderlist);

        for (OrderList listorder: Data.orderlist) {
            Total += listorder.getQuantity() * listorder.getDrink().getPrice();

        }

        orderAdapter = new OrderAdapter(orderlist, this);

        recyclervieworder = findViewById(R.id.RecycleViewOrder);

        recyclervieworder.setAdapter(orderAdapter);

        recyclervieworder.setLayoutManager(new LinearLayoutManager(this));

        paynow = findViewById(R.id.payNow);
        paynow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MyOrder.this,Selesai_Activity.class);
                startActivity(intent);

            }
        });


        TextView harga = findViewById(R.id.myOrderTextView);
        harga.setText("Total: Rp. " + Total);
    }
}