package com.example.ezyfood;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SelesaiAdapter extends RecyclerView.Adapter<SelesaiAdapter.SelesaiViewHolder> {

    ArrayList<OrderList> order;
    Context context;

    public SelesaiAdapter(ArrayList<OrderList> Lorder, Context context) {
        this.order = Lorder;
        this.context = context;
    }

    @NonNull
    @Override
    public SelesaiViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.selesai_row, viewGroup, false);
        return new SelesaiViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SelesaiViewHolder viewHolder, int i) {
        viewHolder.image1.setImageResource(order.get(i).getDrink().getImages());
        viewHolder.text1.setText(order.get(i).getDrink().getName());
        viewHolder.text2.setText(order.get(i).getQuantity() + "x Rp. " + order.get(i).getDrink().getPrice());
    }

    @Override
    public int getItemCount() {
        return order.size();
    }

    public class SelesaiViewHolder extends RecyclerView.ViewHolder {
        TextView text1, text2, qty;
        ImageView image1;


        public SelesaiViewHolder(@NonNull View itemView) {
            super(itemView);
            image1 = itemView.findViewById(R.id.orderImageView);
            text1 = itemView.findViewById(R.id.nama);
            text2 = itemView.findViewById(R.id.harga);
            qty = itemView.findViewById(R.id.BeliBerapa);
        }
    }
}