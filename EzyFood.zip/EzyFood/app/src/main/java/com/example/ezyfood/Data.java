package com.example.ezyfood;

import java.util.Vector;

public class Data {
    public static Vector<OrderList> orderlist = new Vector<>();
}
