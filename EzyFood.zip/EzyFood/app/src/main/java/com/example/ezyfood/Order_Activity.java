package com.example.ezyfood;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Order_Activity extends AppCompatActivity {

    minuman Minuman;
    ImageView mainImageView;
    TextView title, description, quantity;

    private Button button, button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_);
        quantity = (EditText) findViewById(R.id.BeliBerapa);
        quantity.setText("1");
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int qty = Integer.parseInt(quantity.getText().toString());
                Data.orderlist.add(new OrderList(Minuman, qty));
                Intent intent = new Intent(Order_Activity.this, Drink_Activity.class);
                startActivity(intent);
            }
        });

        Button MyOrder = findViewById(R.id.MyOrder);
        MyOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int qty = Integer.parseInt(quantity.getText().toString());
                Data.orderlist.add(new OrderList(Minuman, qty));
                Intent intent = new Intent(Order_Activity.this, MyOrder.class);
                startActivity(intent);
            }
        });

        mainImageView = findViewById(R.id.mainImageView);
        title = findViewById(R.id.title);
        description = findViewById(R.id.description);
        Intent intent = getIntent();

        Minuman = (minuman) intent.getSerializableExtra("drink");
        mainImageView.setImageResource(Minuman.getImages());
        title.setText(Minuman.getName());
        description.setText("Rp. " + Minuman.getPrice());

    }

}