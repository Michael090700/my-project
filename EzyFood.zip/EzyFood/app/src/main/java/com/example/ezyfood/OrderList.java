package com.example.ezyfood;

import java.util.ArrayList;

public class OrderList {

    private minuman drink;
    private int quantity;

    public static ArrayList<OrderList> vListorder = new ArrayList<>();

    public OrderList(minuman drink, int quantity){

        this.drink = drink;
        this.quantity = quantity;
    }

    public minuman getDrink(){
        return drink;
    }

    public int getQuantity(){
        return quantity;
    }
}
