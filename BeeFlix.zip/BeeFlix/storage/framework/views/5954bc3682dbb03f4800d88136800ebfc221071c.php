

<?php $__env->startSection('content'); ?>
<div class="ml-5">
    <?php $__currentLoopData = $genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $G): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1 class="mt-3 mb-2"><?php echo e($G->name); ?></h1>
        <div class="row">
            <?php $__currentLoopData = $movie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $M): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($G->id == $M->genre_id): ?>
                    <div class="col-3 ">
                        <div class="card" style="width: 18rem">
                            <img src="<?php echo e(asset('/Dataset/' . $M->photo_log)); ?>" alt="" class="card-img-top" width="287px" height="287px">
                            <p class="text-center"><?php echo e($M->title); ?></p>
                            <a href="<?php echo e(url('/film/' . $M->id)); ?>" class="btn btn-dark">
                                Click Series
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wilso\Documents\Semester 5\UTS\webprog\UTS\resources\views/view.blade.php ENDPATH**/ ?>