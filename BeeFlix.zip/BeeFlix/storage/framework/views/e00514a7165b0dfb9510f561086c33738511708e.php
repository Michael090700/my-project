

<?php $__env->startSection('content'); ?>
<div class = "ml-5">
    <?php if(isset($category)): ?>
        <h1><?php echo e($category->name); ?></h1>
    <?php else: ?>
        <h1 class="text-center" class="mt-3">All Movie</h1>
    <?php endif; ?>
    <div class="row">
        <?php $__currentLoopData = $movie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $M): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-3 mt-3">
                <div class="card" style="width: 18rem">
                   <h4><p class="text-center"><?php echo e($M->title); ?></p></h4> 
                    <img src="<?php echo e(asset('/Dataset/' . $M->photo_log)); ?>" alt="" class="card-img-top" width="100px" height="300px">
                    <a href="<?php echo e(url('/film/' . $M->id)); ?>" class="btn btn-dark">
                        Click Series
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wilso\Documents\Semester 5\UTS\webprog\UTS\resources\views/genrefilm.blade.php ENDPATH**/ ?>