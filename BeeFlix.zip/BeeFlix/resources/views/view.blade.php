@extends('template')

@section('content')
<div class="ml-5">
    @foreach ($genre as $G)
        <h1 class="mt-3 mb-2">{{ $G->name }}</h1>
        <div class="row">
            @foreach ($movie as $M)
                @if ($G->id == $M->genre_id)
                    <div class="col-3 ">
                        <div class="card" style="width: 18rem">
                            <img src="{{ asset('/Dataset/' . $M->photo_log) }}" alt="" class="card-img-top" width="287px" height="287px">
                            <p class="text-center">{{ $M->title }}</p>
                            <a href="{{ url('/film/' . $M->id) }}" class="btn btn-dark">
                                Click Series
                            </a>
                        </div>
                    </div>
                @endif
            @endforeach
        </div>
    @endforeach
</div>
@endsection
