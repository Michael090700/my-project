@extends('template')

@section('content')
    <div class="row">
        <div class="col = 3 ml-5">
            <div class="card">
                <h2><p class="text-center">{{ $movie->title }}</p></h2>
                <img src="{{ asset('/Dataset/' . $movie->photo_log) }}" alt="" class="card-img-top" width="200px" height="400px">
            </div>
            <div class="col">
                @for ($i = 0; $i < $movie->rating; $i++)
                    <svg class="mt-4 ml-1" width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-star-fill" fill="#ffdf00" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.283.95l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
                    </svg>
                @endfor
            </div>
            <div class="mt-3">{{ $movie->description }}</div> 
            <h6 class="text-center" class="mt-3"> Kategori: 
                <a class="mt-3" href="{{url('/category/'.$category->id)}}">{{$category->name}}</a> 
            </h6>
        </div>
        <div class="col 2 mt-5 mr-5">
            <div>
                <table class="table table-bordered table-striped table-dark">
                    <thead>
                        <tr>
                            <th class="text-center" scope="col">Episodes</th>
                            <th class="text-center" scope="col">Title</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($episodes as $E)
                            <tr>
                                <td class="text-center">{{ $E->episode }}</td>
                                <td class="text-center">{{ $E->title }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                {{ $episodes->links() }}
            </div>
        </div>
    </div>
@endsection
