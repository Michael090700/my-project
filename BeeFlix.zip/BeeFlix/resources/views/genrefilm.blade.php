@extends('template')

@section('content')
<div class = "ml-5">
    @if (isset($category))
        <h1>{{ $category->name }}</h1>
    @else
        <h1 class="text-center" class="mt-3">All Movie</h1>
    @endif
    <div class="row">
        @foreach ($movie as $M)
            <div class="col-3 mt-3">
                <div class="card" style="width: 18rem">
                   <h4><p class="text-center">{{ $M->title }}</p></h4> 
                    <img src="{{ asset('/Dataset/' . $M->photo_log) }}" alt="" class="card-img-top" width="100px" height="300px">
                    <a href="{{ url('/film/' . $M->id) }}" class="btn btn-dark">
                        Click Series
                    </a>
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection
