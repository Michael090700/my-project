<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class movie_seeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('movies')->insert([
            ['genre_id' => '1', 'title' => 'Lucifer', 'photo_log' => 'Lucifer.jpg', 'description' => 'Lucifer Morningstar has decided he is had enough of being the dutiful servant in Hell and decides to spend some time on Earth to better understand humanity. He settles in Los Angeles - the City of Angels.', 'rating' => 5],
            ['genre_id' => '1', 'title' => 'The Crown', 'photo_log' => 'The Crown.jpg', 'description' => "Follows the political rivalries and romance of Queen Elizabeth II's reign and the events that shaped the second half of the twentieth century.",'rating' => 4],
            ['genre_id' => '1', 'title' => 'Elite', 'photo_log' => 'Elite.jpg', 'description' => 'When three working-class teenagers begin attending an exclusive private school in Spain, the clash between them and the wealthy students leads to murder.', 'rating' => 4],
            ['genre_id' => '1', 'title' => 'The 100', 'photo_log' => 'The 100.jpg', 'description' => 'A century after Earth was devastated by a nuclear apocalypse, 100 space station residents are sent to the planet to determine whether it is habitable.', 'rating' => 4],
            ['genre_id' => '2', 'title' => 'Shaun The Sheep', 'photo_log' => 'Shaun The Sheep.jpg', 'description' => 'Shaun is a sheep who doesn not follow the flock - in fact, he leads them into all sorts of scrapes and scraps, turning peace in the valley into mayhem in the meadow. Shaun and his pals run rings around their poor sheepdog Bitzer, as he tries to stop the Farmer finding out what is going on behind his back. Every day brings a new adventure for Shaun.', 'rating' => 4],
            ['genre_id' => '2', 'title' => 'The Boss Baby: Back in Business', 'photo_log' => 'The Boss Baby Back in Business.jpg', 'description' => 'With a little help from his brother and accomplice, Tim, Boss Baby tries to balance family life with his job at Baby Corp headquarters.', 'rating' => 5],
            ['genre_id' => '2', 'title' => 'My Little Pony: Friendship Is Magic', 'photo_log' => 'My Little Pony Friendship Is Magic.jpg', 'description' => 'After learning that her friends, as well as herself, are the magical Elements of Harmony, studious unicorn Twilight Sparkle is sent by her mentor, Princess Celestia, to Ponyville to study the magic of friendship with help from her friends.', 'rating' => 4],
            ['genre_id' => '2', 'title' => 'Spongebob Squarepants', 'photo_log' => 'Spongebob Squarepants.jpg', 'description' => 'The misadventures of a talking sea sponge who works at a fast food restaurant, attends a boating school, and lives in an underwater pineapple.', 'rating' => 5],
            ['genre_id' => '3', 'title' => "The Queen's Gambit", 'photo_log' => "The Queens Gambit.jpg", 'description' => 'In a 1950s orphanage, a young girl reveals an astonishing talent for chess and begins an unlikely journey to stardom while grappling with addiction.', 'rating' => 5],
            ['genre_id' => '3', 'title' => "Emily in Paris", 'photo_log' => "Emily In Paris.jpg", 'description' => 'After landing her dream job in Paris, Chicago marketing exec Emily Cooper embraces her adventurous new life while juggling work, friends and romance.', 'rating' => 4],
            ['genre_id' => '3', 'title' => "Friends", 'photo_log' => "Friends.jpg", 'description' => 'This hit sitcom follows the merry misadventures of six 20-something pals as they navigate the pitfalls of work, life and love in 1990s Manhattan.', 'rating' => 5],
            ['genre_id' => '3', 'title' => "The Witcher", 'photo_log' => "The Witcher.jpg", 'description' => 'Geralt of Rivia, a mutated monster-hunter for hire, journeys toward his destiny in a turbulent world where people often prove more wicked than beasts.', 'rating' => 5]
        ]);
    }
}
