<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call('genre_seeder');
        $this->call('movie_seeder');
        $this->call('episode_seeder');
    }
}
