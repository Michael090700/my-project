<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class episode_seeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('episodes')->insert([
            ['movies_id' => '1', 'episode' => 1, 'title' => 'Pilot'],
            ['movies_id' => '1', 'episode' => 2, 'title' => 'Lucifer, Diam di Sini. Iblis Baik.'],
            ['movies_id' => '1', 'episode' => 3, 'title' => 'Akhirnya, Pangeran Kegelapan'],
            ['movies_id' => '1', 'episode' => 4, 'title' => 'Semua Sifat Jantan'],
            ['movies_id' => '1', 'episode' => 5, 'title' => 'Sepatu'],
            ['movies_id' => '1', 'episode' => 6, 'title' => 'Putra Kesayangan'],
            ['movies_id' => '2', 'episode' => 1, 'title' => 'Wolferton Splash'],
            ['movies_id' => '2', 'episode' => 2, 'title' => 'Hyde Park Corner'],
            ['movies_id' => '2', 'episode' => 3, 'title' => 'Windsor'],
            ['movies_id' => '2', 'episode' => 4, 'title' => 'Act of God'],
            ['movies_id' => '2', 'episode' => 5, 'title' => 'Smoke and Mirrors'],
            ['movies_id' => '2', 'episode' => 6, 'title' => 'Gelignite'],
            ['movies_id' => '3', 'episode' => 1, 'title' => 'Welcome'],
            ['movies_id' => '3', 'episode' => 2, 'title' => 'Desire'],
            ['movies_id' => '3', 'episode' => 3, 'title' => 'Saturday Night'],
            ['movies_id' => '3', 'episode' => 4, 'title' => 'Love is a Drug'],
            ['movies_id' => '3', 'episode' => 5, 'title' => 'Everyone Lies'],
            ['movies_id' => '3', 'episode' => 6, 'title' => 'Everything Will Be Okay'],
            ['movies_id' => '4', 'episode' => 1, 'title' => 'Percobaan'],
            ['movies_id' => '4', 'episode' => 2, 'title' => 'Keterampilan di Bumi'],
            ['movies_id' => '4', 'episode' => 3, 'title' => 'Bahaya di Bumi'],
            ['movies_id' => '4', 'episode' => 4, 'title' => 'Hukum Murphy'],
            ['movies_id' => '4', 'episode' => 5, 'title' => 'Di Ujung Senja'],
            ['movies_id' => '4', 'episode' => 6, 'title' => 'Pelindung Adiknya'],
            ['movies_id' => '5', 'episode' => 1, 'title' => 'Off the Baa!'],
            ['movies_id' => '5', 'episode' => 2, 'title' => 'Bathtime'],
            ['movies_id' => '5', 'episode' => 3, 'title' => 'Shape Up with Shaun'],
            ['movies_id' => '5', 'episode' => 4, 'title' => 'Timmy in a Tizzy'],
            ['movies_id' => '5', 'episode' => 5, 'title' => 'Scrumping'],
            ['movies_id' => '5', 'episode' => 6, 'title' => 'Still Life'],
            ['movies_id' => '6', 'episode' => 1, 'title' => 'Bossa Nova'],
            ['movies_id' => '6', 'episode' => 2, 'title' => 'Misi di Museum'],
            ['movies_id' => '6', 'episode' => 3, 'title' => 'Ga Ba Goo Ba Ga'],
            ['movies_id' => '6', 'episode' => 4, 'title' => 'Pemberontakan Bayi'],
            ['movies_id' => '6', 'episode' => 5, 'title' => 'Lampu, Kamera, Bagan Organisasi!'],
            ['movies_id' => '6', 'episode' => 6, 'title' => 'Reses Besar'],
            ['movies_id' => '7', 'episode' => 1, 'title' => 'Friendship Is Magic: Part 1'],
            ['movies_id' => '7', 'episode' => 2, 'title' => 'Friendship Is Magic: Part 2'],
            ['movies_id' => '7', 'episode' => 3, 'title' => 'The Ticket Master'],
            ['movies_id' => '7', 'episode' => 4, 'title' => 'Applebuck Season'],
            ['movies_id' => '7', 'episode' => 5, 'title' => 'Griffon the Brush-off'],
            ['movies_id' => '7', 'episode' => 6, 'title' => 'Boast Busters'],
            ['movies_id' => '8', 'episode' => 1, 'title' => 'Tentacle-Vision / I Heart Dancing'],
            ['movies_id' => '8', 'episode' => 2, 'title' => 'Growth Spout / Stuck in the Wringer'],
            ['movies_id' => '8', 'episode' => 3, 'title' => 'Someone is in the Kitchen with Sandy / The Inside Job'],
            ['movies_id' => '8', 'episode' => 4, 'title' => 'Greasy Buffoons / Model Sponge'],
            ['movies_id' => '8', 'episode' => 5, 'title' => 'Keep Bikini Bottom Beautiful / A Pal for Gary'],
            ['movies_id' => '8', 'episode' => 6, 'title' => 'Yours, Mine and Mine / Kracked Krabs'],
            ['movies_id' => '9', 'episode' => 1, 'title' => 'Openings'],
            ['movies_id' => '9', 'episode' => 2, 'title' => 'Exchanges'],
            ['movies_id' => '9', 'episode' => 3, 'title' => 'Doubled Pawns'],
            ['movies_id' => '9', 'episode' => 4, 'title' => 'Middle Game'],
            ['movies_id' => '9', 'episode' => 5, 'title' => 'Fork'],
            ['movies_id' => '9', 'episode' => 6, 'title' => 'Adjournment'],
            ['movies_id' => '10', 'episode' => 1, 'title' => 'Emily in Paris'],
            ['movies_id' => '10', 'episode' => 2, 'title' => 'Masculin Féminin'],
            ['movies_id' => '10', 'episode' => 3, 'title' => 'Sexy or Sexist'],
            ['movies_id' => '10', 'episode' => 4, 'title' => 'A Kiss Is Just A Kiss'],
            ['movies_id' => '10', 'episode' => 5, 'title' => 'Faux Amis'],
            ['movies_id' => '10', 'episode' => 6, 'title' => 'Ringarde'],
            ['movies_id' => '11', 'episode' => 1, 'title' => 'The One Where Monica Gets a Roommate (Pilot)'],
            ['movies_id' => '11', 'episode' => 2, 'title' => 'The One with the Sonogram at the End'],
            ['movies_id' => '11', 'episode' => 3, 'title' => 'The One with the Thumb'],
            ['movies_id' => '11', 'episode' => 4, 'title' => 'The One with George Stephanopoulos'],
            ['movies_id' => '11', 'episode' => 5, 'title' => 'The One with the East German Laundry Detergent'],
            ['movies_id' => '11', 'episode' => 6, 'title' => 'The One with the Butt'],
            ['movies_id' => '12', 'episode' => 1, 'title' => 'The End’s Beginning'],
            ['movies_id' => '12', 'episode' => 2, 'title' => 'Four Marks'],
            ['movies_id' => '12', 'episode' => 3, 'title' => 'Betrayer Moon'],
            ['movies_id' => '12', 'episode' => 4, 'title' => 'Of Banquets, Bastards and Burials'],
            ['movies_id' => '12', 'episode' => 5, 'title' => 'Bottled Appetites'],
            ['movies_id' => '12', 'episode' => 6, 'title' => 'Rare Species'],
        ]);
    }
}
